module.exports = {
    jwtSecret: 'your-secret-key',
    jwtExpiration: '1h'
  };
  